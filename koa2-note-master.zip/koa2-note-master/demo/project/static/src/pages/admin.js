import '@babel/polyfill';
import 'whatwg-fetch'
import React from 'react'
import ReactDOM from 'react-dom'
import App from './../apps/admin.jsx'

ReactDOM.render( <App />,
  document.getElementById("app"))
