(function( ){
  alert('hello koa2 static server')
  console.log('hello koa2 static server')
})()
